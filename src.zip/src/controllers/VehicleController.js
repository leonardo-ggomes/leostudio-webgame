// ================================================================
// controllers/VehicleController.js
// ================================================================
import * as THREE from 'three';
import * as S from '../state.js';

const GRAV = -9.81;

export class VehicleController {
  onEnter(entity) {
    this._vel        = new THREE.Vector3();
    this._speed      = 0;
    this._steer      = 0;
    this._grounded   = true;
    this._wheelsAngle = 0;
  }
  onExit(entity) {}

  update(dt, input, entity) {
    const st = entity.controllable.stats;
    const m  = entity.mesh;
    if (!m) return;

    // forwardSign: 1 = model faces -Z (default), -1 = model faces +Z (inverted GLB)
    const sign = st.forwardSign ?? 1;

    const throttle   = input.forward  ? 1 : 0;
    const reversing  = input.backward ? 1 : 0;
    const handbrake  = input.jump;

    // ---- Speed — forward and reverse have independent accel ----
    const targetFwd = throttle * st.topSpeed;
    const targetRev = -reversing * (st.reverseSpeed ?? 4);
    const target    = targetFwd + targetRev;

    const accel = this._speed >= 0
      ? (target >= 0 ? st.accel : st.brake)      // going fwd: accel fwd or brake
      : (target <= 0 ? (st.reverseAccel ?? st.accel * 1.4) : st.brake); // going rev: rev accel or brake

    if (handbrake) {
      this._speed *= Math.max(0, 1 - st.brake * 4 * dt);
    } else {
      this._speed += (target - this._speed) * Math.min(1, accel * dt);
    }
    this._speed *= (1 - st.drag * dt);
    if (Math.abs(this._speed) < 0.02) this._speed = 0;

    // ---- Steering ----
    // A/D also inverted by forwardSign so turning direction is always correct
    const steerInput  = ((input.right ? 1 : 0) - (input.left ? 1 : 0)) * sign;
    const speedRatio  = Math.abs(this._speed) / (st.topSpeed + .001);
    const steerFactor = Math.max(0.2, 1 - speedRatio * 0.5);
    const targetSteer = steerInput * st.steerMax * steerFactor;
    this._steer += (targetSteer - this._steer) * Math.min(1, st.steerReturn * dt);

    // ---- Yaw — sign flips when reversing ----
    if (Math.abs(this._speed) > 0.1) {
      const dir      = this._speed >= 0 ? 1 : -1;
      const turnRate = Math.abs(this._speed / st.topSpeed) * this._steer * st.turnRate * dir;
      m.rotation.y  -= turnRate * dt * sign;
    }

    // ---- Move — forwardSign inverts the heading ----
    const heading = new THREE.Vector3(
      -Math.sin(m.rotation.y) * sign,
       0,
      -Math.cos(m.rotation.y) * sign,
    );
    this._vel.copy(heading).multiplyScalar(this._speed);
    this._vel.y += GRAV * dt;
    m.position.addScaledVector(this._vel, dt);

    // Ground
    const box = new THREE.Box3().setFromObject(m);
    if (box.min.y <= 0) {
      m.position.y -= box.min.y;
      if (this._vel.y < 0) { this._vel.y = 0; this._grounded = true; }
    } else {
      this._grounded = false;
    }

    // Wheel visual — steer on Y (front wheels), roll on X (all wheels)
    this._wheelsAngle = this._steer;
    const wheelRoll = this._speed * dt * 0.8; // accumulate roll based on speed
    m.traverse(c => {
      if (c.userData.wheelFront || c.userData.wheel) {
        c.rotation.x += wheelRoll * sign; // rolling animation
      }
      if (c.userData.wheelFront) {
        c.rotation.y = this._wheelsAngle; // steering
      }
    });
  }

  getVelocity() {
    // Retorna vetor de velocidade para herança de vel (ex: sair de veículo aéreo)
    return this._vel;
  }

  getCameraOffset(entity) {
    const st   = entity.controllable.stats;
    const sign = st.forwardSign ?? 1;
    return {
      yawOffset:    entity.mesh.rotation.y + Math.PI * sign,
      pitchOffset:  S.camPitch,
      distance:     st.camD ?? 7.5,
      heightTarget: st.camY ?? 2.8,
    };
  }

  getSpeed()   { return this._speed; }
  getSteer()   { return this._steer; }
  isGrounded() { return this._grounded; }
  getAnimState() { return 'sit'; }
}
