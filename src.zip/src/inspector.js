// ================================================================
// inspector.js — Right panel: Transform / Physics / Char / Scripts
// ================================================================
import * as S from './state.js';
import * as THREE from 'three';

const $ = id => document.getElementById(id);

// ----------------------------------------------------------------
// TAB SWITCHING
// ----------------------------------------------------------------
const TAB_NAMES = ['xform','physics','ctrl','anim','effects','camera','scripts'];
const TAB_META = {'xform': ('⬡', 'Transform'), 'physics': ('⚙', 'Física / Collider'), 'ctrl': ('🎮', 'Controller'), 'anim': ('▶', 'Animações'), 'effects': ('✨', 'Efeitos Especiais'), 'camera': ('◎', 'Câmera'), 'scripts': ('{}', 'Scripts')};

export function switchTab(name) {
  document.querySelectorAll('.ins-tab').forEach((t,i) => t.classList.toggle('active', TAB_NAMES[i]===name));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.toggle('active', p.id==='tab-'+name));
  // Update content header
  const meta = TAB_META[name];
  if (meta) {
    const iconEl = document.getElementById('ins-content-hdr')?.querySelector('.hdr-icon');
    const txtEl  = document.getElementById('ins-content-hdr-txt');
    if (iconEl) iconEl.textContent = meta[0];
    if (txtEl)  txtEl.textContent  = meta[1];
  }
}
export function toggleSec(hdr)     { hdr.closest('.ins-sec').classList.toggle('coll'); }
export function toggleCharSec(hdr) { const b=hdr.nextElementSibling; b.style.display=b.style.display==='none'?'':'none'; }

// ----------------------------------------------------------------
// FULL REFRESH
// ----------------------------------------------------------------
export function refresh() {
  const has = !!S.selEnt;
  ['nsel-xf','nsel-phy','nsel-sc'].forEach(id => $(id).style.display = has?'none':'flex');
  ['xf-fields','phy-fields','sc-fields'].forEach(id => $(id).style.display = has?'block':'none');

  const hasChar = has && !!S.selEnt.controllable;
  $('nsel-ctrl').style.display  = hasChar ? 'none' : 'flex';
  $('ctrl-fields').style.display = hasChar ? 'block' : 'none';
  $('nsel-ctrl').querySelector('.no-sel-txt').textContent =
    has ? 'Sem componente Controller\n(Add > Humanoid, Veículo, Moto, Cavalo...)' : 'Nenhum objeto\nselecionado';

  if (!has) return;
  refreshXf();
  refreshPhy();
  if (hasChar) refreshControllable();
  refreshSc();
}

// ----------------------------------------------------------------
// TRANSFORM
// ----------------------------------------------------------------
export function refreshXf() {
  if (!S.selEnt) return;
  const m = S.selEnt.mesh, f = v => parseFloat(v.toFixed(3));
  $('px').value=f(m.position.x); $('py').value=f(m.position.y); $('pz').value=f(m.position.z);
  $('rx').value=f(m.rotation.x*180/Math.PI); $('ry').value=f(m.rotation.y*180/Math.PI); $('rz').value=f(m.rotation.z*180/Math.PI);
  $('sx').value=f(m.scale.x); $('sy').value=f(m.scale.y); $('sz').value=f(m.scale.z);
  $('obj-name').value=S.selEnt.name;
  $('obj-vis').checked=S.selEnt.visible;
  $('obj-layer').value=S.selEnt.layer||'default';
}
export function applyXf() {
  if (!S.selEnt) return;
  const m = S.selEnt.mesh;
  m.position.set(+$('px').value||0, +$('py').value||0, +$('pz').value||0);
  m.rotation.set((+$('rx').value||0)*Math.PI/180, (+$('ry').value||0)*Math.PI/180, (+$('rz').value||0)*Math.PI/180);
  m.scale.set(+$('sx').value||1, +$('sy').value||1, +$('sz').value||1);
}
export function applyName() { if (S.selEnt) { S.selEnt.name = $('obj-name').value; refreshHier(); } }
export function applyVis()  { if (S.selEnt) { S.selEnt.visible = $('obj-vis').checked; S.selEnt.mesh.visible = S.selEnt.visible; refreshHier(); } }
export function resetXf()   { if (!S.selEnt) return; S.selEnt.mesh.position.set(0,0,0); S.selEnt.mesh.rotation.set(0,0,0); S.selEnt.mesh.scale.set(1,1,1); refreshXf(); }

// ----------------------------------------------------------------
// PHYSICS
// ----------------------------------------------------------------
export function refreshPhy() {
  if (!S.selEnt?.physics) return;
  const ph = S.selEnt.physics;
  $('ph-on').checked=ph.enabled; $('ph-type').value=ph.type||'dynamic';
  $('ph-mass').value=ph.mass||1; $('ph-fric').value=ph.friction||.5;
  $('ph-rest').value=ph.restitution||.3; $('ph-grav').checked=ph.gravity!==false;
  $('ph-col').value=ph.collider||'box';
}
export function applyPhy() {
  if (!S.selEnt?.physics) return;
  const ph = S.selEnt.physics;
  ph.enabled=$('ph-on').checked; ph.type=$('ph-type').value;
  ph.mass=+$('ph-mass').value; ph.friction=+$('ph-fric').value;
  ph.restitution=+$('ph-rest').value; ph.gravity=$('ph-grav').checked;
  ph.collider=$('ph-col').value;
}
// ---- Collider debug helpers per entity ----
const _colHelpers = new Map(); // ent.id → THREE.Object3D

export function toggleColViz() {
  const ent = S.selEnt;
  if (!ent) return;
  const show = $('ph-show').checked;

  // Remove existing helper for this entity
  const old = _colHelpers.get(ent.id);
  if (old) { S.scene.remove(old); _colHelpers.delete(ent.id); }

  if (!show) return;

  const ph  = ent.physics;
  const col = ph?.collider || 'box';
  const mat = new THREE.MeshBasicMaterial({
    color: 0x3ecf8e, transparent: true, opacity: 0.25,
    wireframe: true, depthTest: false,
  });

  // Build geometry from the object's bounding box
  const bbox = new THREE.Box3().setFromObject(ent.mesh);
  const size = new THREE.Vector3();
  bbox.getSize(size);
  const center = new THREE.Vector3();
  bbox.getCenter(center);

  let geo;
  if (col === 'sphere') {
    const r = Math.max(size.x, size.y, size.z) * 0.5;
    geo = new THREE.SphereGeometry(r, 16, 12);
  } else if (col === 'capsule') {
    const r = Math.max(size.x, size.z) * 0.5;
    const h = Math.max(0, size.y - r * 2);
    // Approximate capsule with cylinder + 2 hemispheres (or just a tall sphere)
    geo = new THREE.CylinderGeometry(r, r, h, 16, 1, true);
  } else {
    // box (default)
    geo = new THREE.BoxGeometry(size.x, size.y, size.z);
  }

  const helper = new THREE.Mesh(geo, mat);
  helper.position.copy(center);
  helper.userData._isColHelper = true;
  S.scene.add(helper);
  _colHelpers.set(ent.id, helper);
}

/** Called every frame from main loop to keep helpers in sync with moving objects */
export function updateColHelpers() {
  _colHelpers.forEach((helper, id) => {
    const ent = S.entities.find(e => e.id === id);
    if (!ent) { S.scene.remove(helper); _colHelpers.delete(id); return; }
    const bbox = new THREE.Box3().setFromObject(ent.mesh);
    const center = new THREE.Vector3();
    bbox.getCenter(center);
    helper.position.copy(center);
  });
}

/** Remove all helpers (e.g. on play/stop) */
export function clearColHelpers() {
  _colHelpers.forEach(h => S.scene.remove(h));
  _colHelpers.clear();
}

// ----------------------------------------------------------------
// CHARACTER
// ----------------------------------------------------------------
export function refreshChar() {
  if (!S.selEnt?.char) return;
  const ch = S.selEnt.char;
  $('ch-spd').value=ch.speed; $('ch-spr').value=ch.sprint; $('ch-jmp').value=ch.jump;
  $('ch-acc').value=ch.accel; $('ch-rot').value=ch.rotSpd;
  $('ch-camy').value=ch.camY; $('ch-camd').value=ch.camD;
  ['aim','car','cov','rol','crc','int'].forEach(k => {
    const el=$('ca-'+k); if (el) el.checked=ch.actions?.[k]||false;
  });
  buildKBUI(ch.keybinds);
}
export function applyChar() {
  if (!S.selEnt?.char) return;
  const ch = S.selEnt.char;
  ch.speed=+$('ch-spd').value; ch.sprint=+$('ch-spr').value; ch.jump=+$('ch-jmp').value;
  ch.accel=+$('ch-acc').value; ch.rotSpd=+$('ch-rot').value;
  ch.camY=+$('ch-camy').value; ch.camD=+$('ch-camd').value;
}

// ----------------------------------------------------------------
// KEYBINDS
// ----------------------------------------------------------------
let listeningFor = null;

export function buildKBUI(kb) {
  const c = $('kb-list'); c.innerHTML = '';
  Object.entries(kb).forEach(([action, bind]) => {
    const row = document.createElement('div'); row.className='kb-row';
    row.innerHTML=`<div class="kb-action">${bind.action}</div><input class="kb-key" id="kbi-${action}" value="${bind.label}" readonly onclick="startListen('${action}')" title="Clique para reatribuir">`;
    c.appendChild(row);
  });
}
export function startListen(action) {
  if (!S.selEnt?.char) return; listeningFor=action;
  const el=$('kbi-'+action); el.classList.add('listening'); el.value='...';
}
export function onKeyForRebind(e) {
  if (!listeningFor || !S.selEnt?.char) return false;
  e.preventDefault(); e.stopPropagation();
  const lbl = e.key===' '?'Space':e.key.length===1?e.key.toUpperCase():e.key;
  S.selEnt.char.keybinds[listeningFor].key   = e.code;
  S.selEnt.char.keybinds[listeningFor].label = lbl;
  const el = $('kbi-'+listeningFor);
  if (el) { el.value=lbl; el.classList.remove('listening'); }
  listeningFor = null;
  return true;
}
export function resetKB() {
  if (!S.selEnt?.char) return;
  S.selEnt.char.keybinds = JSON.parse(JSON.stringify(S.DEF_KB));
  buildKBUI(S.selEnt.char.keybinds);
}
export function isListening() { return !!listeningFor; }

// ----------------------------------------------------------------
// SCRIPTS
// ----------------------------------------------------------------
export function refreshSc() {
  if (!S.selEnt) return;
  const list=$('sc-list'); list.innerHTML='';
  (S.selEnt.scripts||[]).forEach(sn => {
    const c=document.createElement('div'); c.className='sc-card';
    c.innerHTML=`<div class="sc-card-hdr"><div class="sc-dot"></div><div class="sc-name-lbl">${sn}</div><span class="sc-edit" onclick="openSCEditor('${sn}')">✎ Editar</span><span class="sc-edit" style="color:var(--red)" onclick="rmScript('${sn}')">✕</span></div><div style="font-size:10px;color:var(--text3);margin-top:3px">onStart · onUpdate · onCollision</div>`;
    list.appendChild(c);
  });
}

// ----------------------------------------------------------------
// HIERARCHY
// ----------------------------------------------------------------
export function refreshHier() {
  const list=$('hier-list'); list.innerHTML='';
  S.entities.forEach(ent => {
    const item=document.createElement('div');
    item.className=`h-item${ent===S.selEnt?' sel':''}${!ent.visible?' hidden':''}`;
    const hasPh=ent.physics?.enabled, hasCtrl=!!ent.controllable;
    item.innerHTML=`<span class="h-item-icon">${S.ICONS[ent.type]||'◻'}</span><span class="h-item-name">${ent.name}</span>${hasCtrl?'<span class="h-tag">ctrl</span>':''}${hasPh?'<span class="h-tag phy">phy</span>':''}<span class="h-item-vis" onclick="togVis(event,${ent.id})">${ent.visible?'◎':'○'}</span>`;
    item.addEventListener('click', () => window._selectEnt(ent));
    list.appendChild(item);
  });
}

// ----------------------------------------------------------------
// CONTROLLABLE (replaces legacy char)
// ----------------------------------------------------------------
export function refreshControllable() {
  const ent = S.selEnt;
  const c   = ent?.controllable;
  if (!c) return;

  // Set type dropdown
  const typeEl = $('ct-type');
  if (typeEl) typeEl.value = c.type;

  // Show correct stats panel (calls back to main.js via window)
  if (window._showCtrlStats) window._showCtrlStats(c.type);

  // Populate stat fields — iterate stats keys
  Object.entries(c.stats).forEach(([k, v]) => {
    const el = $('ct-' + k);
    if (el) el.value = v;
  });

  // Keybinds
  buildKBUI(c.keybinds);
}

export function applyControllable() {
  const c = S.selEnt?.controllable;
  if (!c) return;
  // Read only the keys that belong to this type's stats
  Object.keys(c.stats).forEach(k => {
    const el = $('ct-' + k);
    if (el && el.value !== '') c.stats[k] = parseFloat(el.value) || 0;
  });
}

export function applyLayer() {
  if (!S.selEnt) return;
  S.selEnt.layer = $('obj-layer').value;
}